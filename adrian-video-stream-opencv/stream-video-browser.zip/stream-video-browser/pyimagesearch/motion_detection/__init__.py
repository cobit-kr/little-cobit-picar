# import the necessary packages
from .singlemotiondetector import SingleMotionDetector
